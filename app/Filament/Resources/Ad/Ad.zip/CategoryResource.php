<?php

namespace App\Filament\Resources\Ad;

use App\Filament\Resources\Ad\CategoryResource\Pages;
use App\Filament\Resources\Ad\CategoryResource\RelationManagers;
use App\Models\Ad\Category;
use Filament\Forms;
use Filament\Forms\Components\BelongsToSelect;
use Filament\Forms\Components\Builder\Block;
use Filament\Forms\Components\Card;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Builder as FormBuilder;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Filament\Tables\Columns\BooleanColumn;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class CategoryResource extends Resource
{
 protected static ?string $model = Category::class;
 protected static ?string $navigationIcon = 'heroicon-o-collection';
 protected static ?string $navigationGroup = 'Ads';

 public static function form(Form $form): Form
 {
  $schema = [
   Card::make()
       ->schema([
                 Grid::make()
                     ->schema([
                               TextInput::make('name')
                                        ->required()
                                        ->reactive()
                                        ->afterStateUpdated(fn($state, callable $set) => $set('slug',
                                                                                              Str::slug($state))),
                               TextInput::make('slug')
                                        ->disabled()
                                        ->required()
                                        ->unique(Category::class, 'slug', fn($record) => $record),
                              ]),
                 BelongsToSelect::make('parent_id')
                                ->label('Parent')
                                ->relationship('parent', 'name')
                                ->searchable()
                                ->placeholder('Select parent category'),
                 Toggle::make('is_visible')
                       ->label('Visible to customers.')
                       ->default(true),
                 RichEditor::make('description')
                           ->disableToolbarButtons([
                                                    'attachFiles',
                                                    'codeBlock',
                                                   ]),
                 FormBuilder::make('attributes')->dehydrateStateUsing(function ($state) {
                  dump($state);
                  return $state;
                 })
                            ->disableItemMovement(function () {
                             //در بخش آگهی غیر فعال باشه در دسته بندی فعال باشه
                             return false;
                            })
                            ->blocks([
                                      Block::make('heading')
                                           ->schema([
                                                     TextInput::make('content')
                                                              ->required(),
                                                     Select::make('level')
                                                           ->options([
                                                                      'h1' => 'Heading 1',
                                                                      'h2' => 'Heading 2',
                                                                      'h3' => 'Heading 3',
                                                                      'h4' => 'Heading 4',
                                                                      'h5' => 'Heading 5',
                                                                      'h6' => 'Heading 6',
                                                                     ])
                                                           ->required(),
                                                    ]),
                                      Block::make('paragraph')
                                           ->schema([
                                                     MarkdownEditor::make('content')
                                                                   ->required(),
                                                    ]),
                                      Block::make('image')
                                           ->schema([
                                                     FileUpload::make('url')
                                                               ->image()
                                                               ->required(),
                                                     TextInput::make('alt')
                                                              ->label('Alt text')
                                                              ->required(),
                                                    ]),
                                      Block::make('attribute')
                                           ->schema([
                                                     Select::make('type')
                                                           ->options([
                                                                      'TextInput' => 'TextInput',
                                                                      'Select' => 'Select',
                                                                      'MarkdownEditor' => 'MarkdownEditor',
                                                                     ])
                                                           ->afterStateUpdated(function (callable $set, $state) {
//                                                            if ($state === 'MarkdownEditor') {
                                                             $set('value', '');
//                                                            }
                                                           })
                                                           ->required()
                                                           ->reactive(),
                                                     TextInput::make('name')
                                                              ->required()
                                                     /* ->afterStateUpdated(function (TextInput $component,
                                                                                    callable    $set, $state) {
                                                       $set('value', '');
                                                      })*/,
                                                     TextInput::make('value')
//                                                              ->dehydrateStateUsing(fn($state) => '')
                                                              ->visible(false),
                                                     Toggle::make('is_visible')
                                                           ->label('Visible to customers.')
                                                           ->default(true),
                                                     Toggle::make('is_require')
                                                           ->label('is_require')
                                                           ->default(true),
                                                     Toggle::make('is_filter')
                                                           ->label('is_filter')
                                                           ->default(true),
                                                    ]),
                                     ])
                ])
       ->columnSpan(2),
   Card::make()
       ->schema([
                 Placeholder::make('created_at')
                            ->label('Created at')
                            ->content(fn(?Category $record): string => $record ? $record->created_at->diffForHumans() : '-'),
                 Placeholder::make('updated_at')
                            ->label('Last modified at')
                            ->content(fn(?Category $record): string => $record ? $record->updated_at->diffForHumans() : '-'),
                ])
       ->columnSpan(1),
  ];
  return $form->schema($schema)
              ->columns(3);
 }

 public static function table(Table $table): Table
 {
  $columns = [
   TextColumn::make('name')
             ->label('Name')
             ->searchable()
             ->sortable(),
   TextColumn::make('parent.name')
             ->label('Parent')
             ->searchable()
             ->sortable(),
   BooleanColumn::make('is_visible')
                ->label('Visibility')
                ->sortable(),
   TextColumn::make('updated_at')
             ->label('Updated Date')
             ->date()
             ->sortable(),
  ];
  return $table->columns($columns)
               ->filters([//
                         ]);
 }

 public static function getRelations(): array
 {
  return [//
  ];
 }

 public static function getPages(): array
 {
  return [
   'index' => Pages\ListCategories::route('/'),
   'create' => Pages\CreateCategory::route('/create'),
   'edit' => Pages\EditCategory::route('/{record}/edit'),
  ];
 }
}
